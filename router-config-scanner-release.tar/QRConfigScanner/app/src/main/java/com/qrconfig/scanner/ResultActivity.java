package com.qrconfig.scanner;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import org.json.JSONException;

public class ResultActivity extends AppCompatActivity {

    private TextView tvRouterIP, tvAdminURL, tvWifiName, tvWifiPassword, 
                   tvAdminUsername, tvAdminPassword;
    private Button btnCopyAll, btnCopyWifi, btnCopyAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initViews();
        
        String qrContent = getIntent().getStringExtra("qr_content");
        parseQRContent(qrContent);
    }

    private void initViews() {
        tvRouterIP = findViewById(R.id.tv_router_ip);
        tvAdminURL = findViewById(R.id.tv_admin_url);
        tvWifiName = findViewById(R.id.tv_wifi_name);
        tvWifiPassword = findViewById(R.id.tv_wifi_password);
        tvAdminUsername = findViewById(R.id.tv_admin_username);
        tvAdminPassword = findViewById(R.id.tv_admin_password);
        
        btnCopyAll = findViewById(R.id.btn_copy_all);
        btnCopyWifi = findViewById(R.id.btn_copy_wifi);
        btnCopyAdmin = findViewById(R.id.btn_copy_admin);
        
        btnCopyAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyAllInfo();
            }
        });
        
        btnCopyWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyWifiInfo();
            }
        });
        
        btnCopyAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                copyAdminInfo();
            }
        });
    }

    private void parseQRContent(String qrContent) {
        try {
            JSONObject json = new JSONObject(qrContent);
            
            String routerIP = json.optString("router_ip", "未提供");
            String adminURL = json.optString("admin_url", "未提供");
            String wifiName = json.optString("wifi_name", "未提供");
            String wifiPassword = json.optString("wifi_password", "未提供");
            String adminUsername = json.optString("admin_username", "未提供");
            String adminPassword = json.optString("admin_password", "未提供");
            
            tvRouterIP.setText("路由器IP: " + routerIP);
            tvAdminURL.setText("管理地址: " + adminURL);
            tvWifiName.setText("WiFi名称: " + wifiName);
            tvWifiPassword.setText("WiFi密码: " + wifiPassword);
            tvAdminUsername.setText("管理员账号: " + adminUsername);
            tvAdminPassword.setText("管理员密码: " + adminPassword);
            
        } catch (JSONException e) {
            Toast.makeText(this, "二维码格式错误", Toast.LENGTH_LONG).show();
            tvRouterIP.setText("无法解析二维码内容: " + qrContent);
        }
    }

    private void copyAllInfo() {
        StringBuilder allInfo = new StringBuilder();
        allInfo.append(tvRouterIP.getText()).append("\n");
        allInfo.append(tvAdminURL.getText()).append("\n");
        allInfo.append(tvWifiName.getText()).append("\n");
        allInfo.append(tvWifiPassword.getText()).append("\n");
        allInfo.append(tvAdminUsername.getText()).append("\n");
        allInfo.append(tvAdminPassword.getText());
        
        copyToClipboard(allInfo.toString());
        Toast.makeText(this, "已复制所有信息", Toast.LENGTH_SHORT).show();
    }

    private void copyWifiInfo() {
        String wifiInfo = tvWifiName.getText() + "\n" + tvWifiPassword.getText();
        copyToClipboard(wifiInfo);
        Toast.makeText(this, "已复制WiFi信息", Toast.LENGTH_SHORT).show();
    }

    private void copyAdminInfo() {
        String adminInfo = tvAdminURL.getText() + "\n" + 
                          tvAdminUsername.getText() + "\n" + 
                          tvAdminPassword.getText();
        copyToClipboard(adminInfo);
        Toast.makeText(this, "已复制管理员信息", Toast.LENGTH_SHORT).show();
    }

    private void copyToClipboard(String text) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("路由器配置", text);
        clipboard.setPrimaryClip(clip);
    }
}
