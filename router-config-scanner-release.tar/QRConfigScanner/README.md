# 路由器配置二维码扫描器

一个可以扫描二维码快速获取路由器配置信息的Android应用。

## 功能特点

- 📱 快速扫描路由器配置二维码
- 📋 一键复制所有配置信息
- 🔄 支持单独复制WiFi信息或管理员信息
- 🔐 安全的本地解析，无需网络连接
- 📊 清晰的配置信息展示

## 技术架构

### Android 应用

- **开发语言**: Java
- **最低支持**: Android 7.0 (API 24)
- **目标平台**: Android 14 (API 34)
- **核心库**: 
  - ZXing (二维码扫描)
  - Material Components (UI设计)
  - AndroidX (现代Android组件)

### 二维码格式

应用使用JSON格式存储配置信息：

```json
{
  "router_ip": "192.168.1.1",
  "admin_url": "http://192.168.1.1/admin", 
  "wifi_name": "MyWiFi",
  "wifi_password": "password123",
  "admin_username": "admin",
  "admin_password": "admin123"
}
```

## 安装使用

### 1. 环境要求

- Android Studio Arctic Fox 或更高版本
- JDK 8 或更高版本
- Android SDK API 34

### 2. 构建应用

```bash
# 克隆项目
git clone <项目地址>
cd QRConfigScanner

# 在Android Studio中打开项目
# 点击 Build > Build Bundle(s) / APK(s) > Build APK(s)
```

### 3. 生成测试二维码

使用提供的Python脚本生成测试二维码：

```bash
# 安装依赖
pip install qrcode[pil]

# 运行生成器
python qr_generator.py
```

按提示输入路由器配置信息，脚本会生成 `router_config_qr.png` 文件。

## 应用权限

应用需要以下权限：

- `CAMERA`: 用于扫描二维码（运行时请求）

## 使用流程

1. 打开应用，点击"扫描二维码"
2. 授予相机权限
3. 将路由器配置二维码放入扫描框
4. 系统自动识别并解析配置信息
5. 查看并复制需要的配置信息

## 项目结构

```
QRConfigScanner/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/qrconfig/scanner/
│   │   │   │   ├── MainActivity.java          # 主界面
│   │   │   │   ├── ScanActivity.java          # 扫描界面
│   │   │   │   └── ResultActivity.java        # 结果展示界面
│   │   │   ├── res/
│   │   │   │   ├── layout/                    # 界面布局
│   │   │   │   └── values/                    # 资源文件
│   │   │   └── AndroidManifest.xml           # 应用清单
│   │   └── build.gradle                      # 应用级构建配置
├── qr_generator.py                            # 二维码生成器
├── build.gradle                               # 项目级构建配置
└── README.md                                  # 项目说明
```

## 核心代码说明

### 扫描功能 (ScanActivity.java)

使用 ZXing 库的 `IntentIntegrator` 实现二维码扫描：

```java
IntentIntegrator integrator = new IntentIntegrator(this);
integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
integrator.setPrompt("将二维码放入框内");
integrator.initiateScan();
```

### 数据解析 (ResultActivity.java)

解析JSON格式的二维码内容：

```java
JSONObject json = new JSONObject(qrContent);
String routerIP = json.optString("router_ip", "未提供");
String wifiPassword = json.optString("wifi_password", "未提供");
```

### 剪贴板功能

一键复制配置信息到系统剪贴板：

```java
ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
ClipData clip = ClipData.newPlainText("路由器配置", text);
clipboard.setPrimaryClip(clip);
```

## 扩展功能建议

- [ ] 支持批量扫描多个路由器
- [ ] 历史记录功能
- [ ] 二维码导出功能
- [ ] WiFi自动连接功能（需要特殊权限）
- [ ] 多语言支持
- [ ] 深色模式

## 技术难点解决

### 二维码数据大小限制

标准QR Code最多支持约2KB数据。如果配置信息较多，可以考虑：

1. 压缩JSON数据
2. 使用多个二维码分片传输
3. 使用URL短链接指向云端配置

### 相机权限兼容

针对不同Android版本的相机权限处理：

```java
if (checkCameraPermission()) {
    startScanner();
} else {
    requestCameraPermission();
}
```

### JSON解析异常处理

确保二维码格式错误时应用不会崩溃：

```java
try {
    JSONObject json = new JSONObject(qrContent);
    // 解析逻辑
} catch (JSONException e) {
    Toast.makeText(this, "二维码格式错误", Toast.LENGTH_LONG).show();
}
```

## 开源协议

MIT License

## 技术支持

如有问题或建议，请提交Issue或Pull Request。

---

**注意**: 本应用仅用于合法的路由器配置管理，请勿用于未授权访问他人设备。
