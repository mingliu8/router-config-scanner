#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
路由器配置二维码生成器
用于生成包含路由器配置信息的二维码
"""

import json
import qrcode
from qrcode.constants import ERROR_CORRECT_H

def generate_router_qr(router_ip, admin_url, wifi_name, wifi_password, 
                      admin_username, admin_password, output_file="router_config.png"):
    """
    生成路由器配置二维码
    
    参数:
        router_ip: 路由器IP地址
        admin_url: 管理地址
        wifi_name: WiFi名称
        wifi_password: WiFi密码
        admin_username: 管理员账号
        admin_password: 管理员密码
        output_file: 输出文件名
    """
    
    # 构建JSON数据
    config_data = {
        "router_ip": router_ip,
        "admin_url": admin_url,
        "wifi_name": wifi_name,
        "wifi_password": wifi_password,
        "admin_username": admin_username,
        "admin_password": admin_password
    }
    
    # 转换为JSON字符串
    json_string = json.dumps(config_data, ensure_ascii=False)
    
    print(f"生成的JSON数据: {json_string}")
    
    # 创建二维码，使用高容错率
    qr = qrcode.QRCode(
        version=1,
        error_correction=ERROR_CORRECT_H,  # 高容错率，约30%可恢复
        box_size=10,
        border=4,
    )
    
    qr.add_data(json_string)
    qr.make(fit=True)
    
    # 生成二维码图片
    img = qr.make_image(fill_color="black", back_color="white")
    
    # 保存图片
    img.save(output_file)
    print(f"二维码已保存到: {output_file}")
    
    return json_string

def main():
    """示例使用"""
    # 示例配置
    config = {
        "router_ip": "192.168.1.1",
        "admin_url": "http://192.168.1.1/admin",
        "wifi_name": "OfficeWiFi_5G",
        "wifi_password": "SecurePassword2024!",
        "admin_username": "admin",
        "admin_password": "AdminPass123!"
    }
    
    print("=== 路由器配置二维码生成器 ===\n")
    
    # 从用户输入获取配置信息
    print("请输入路由器配置信息:")
    router_ip = input(f"路由器IP [{config['router_ip']}]: ") or config['router_ip']
    admin_url = input(f"管理地址 [{config['admin_url']}]: ") or config['admin_url']
    wifi_name = input(f"WiFi名称 [{config['wifi_name']}]: ") or config['wifi_name']
    wifi_password = input(f"WiFi密码 [{config['wifi_password']}]: ") or config['wifi_password']
    admin_username = input(f"管理员账号 [{config['admin_username']}]: ") or config['admin_username']
    admin_password = input(f"管理员密码 [{config['admin_password']}]: ") or config['admin_password']
    
    # 生成二维码
    generate_router_qr(
        router_ip=router_ip,
        admin_url=admin_url,
        wifi_name=wifi_name,
        wifi_password=wifi_password,
        admin_username=admin_username,
        admin_password=admin_password,
        output_file="router_config_qr.png"
    )
    
    print("\n✓ 二维码生成完成！")
    print("你可以用APP扫描这个二维码来获取路由器配置信息。")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n操作取消")
    except Exception as e:
        print(f"错误: {e}")
