# GitHub Actions 自动构建 APK 指南

## 快速开始（5分钟完成）

### 第一步：准备 GitHub 仓库

1. **创建 GitHub 仓库**
   - 登录 https://github.com
   - 点击右上角 "+" → "New repository"
   - 仓库名称：`router-config-scanner`
   - 设置为 Public 或 Private 都可以
   - 点击 "Create repository"

### 第二步：上传项目文件

**方式A：网页上传（最简单）**
1. 在新创建的仓库页面，点击 "uploading an existing file"
2. 把以下文件拖拽上传到仓库：
   ```
   QRConfigScanner/（整个文件夹）
   .github/workflows/build-apk.yml
   ```
3. 填写提交信息："Initial commit - Router Config Scanner"
4. 点击 "Commit changes"

**方式B：Git 命令上传**
```bash
# 初始化仓库
git init
git add QRConfigScanner/ .github/
git commit -m "Initial commit - Router Config Scanner"

# 关联远程仓库（替换YOUR_USERNAME为你的GitHub用户名）
git remote add origin https://github.com/YOUR_USERNAME/router-config-scanner.git

# 推送代码
git branch -M main
git push -u origin main
```

### 第三步：触发自动构建

**方式A：自动触发（推送后自动构建）**
- 代码推送成功后，GitHub Actions 会自动开始构建
- 进入仓库的 "Actions" 标签页查看构建进度
- 构建时间：约 5-10 分钟

**方式B：手动触发（可选）**
1. 进入仓库的 "Actions" 标签页
2. 选择 "Build Android APK" 工作流
3. 点击 "Run workflow" → "Run workflow"

### 第四步：下载 APK

**方式A：从 Actions 下载**
1. 构建完成后，进入 "Actions" 标签页
2. 点击最新的构建任务
3. 在 "Artifacts" 部分找到 `router-config-scanner-apk`
4. 点击下载，解压后得到 `app-debug.apk`

**方式B：从 Releases 下载**
1. 进入仓库的 "Releases" 标签页
2. 找到最新的预发布版本
3. 下载 `app-debug.apk`

## 详细说明

### 文件结构
```
router-config-scanner/
├── QRConfigScanner/          # Android 项目主目录
│   ├── app/                  # 应用模块
│   ├── build.gradle          # 项目级构建文件
│   ├── settings.gradle       # Gradle 设置
│   └── gradle.properties     # Gradle 属性
└── .github/
    └── workflows/
        └── build-apk.yml      # GitHub Actions 配置文件
```

### 工作流程
1. **代码推送** → 2. **自动触发构建** → 3. **编译 APK** → 4. **上传下载**

### 构建时间
- 首次构建：5-10 分钟
- 后续构建：3-5 分钟

### 构建产物
- **APK 文件**：`app-debug.apk`
- **文件大小**：约 3-5 MB
- **签名类型**：Debug 签名（可安装但不能发布到应用商店）

## 常见问题

### Q: 构建失败怎么办？
A: 
1. 检查 "Actions" 标签页的构建日志
2. 确认所有文件都已正确上传
3. 查看是否有语法错误或依赖问题

### Q: 如何修改应用配置？
A: 编辑以下文件后重新推送：
- `QRConfigScanner/app/build.gradle` - 修改应用信息
- `QRConfigScanner/app/src/main/AndroidManifest.xml` - 修改权限和配置

### Q: 如何生成 Release 版本的 APK？
A: 修改 `.github/workflows/build-apk.yml` 中的构建命令：
```yaml
- name: Build with Gradle
  run: |
    cd QRConfigScanner
    ./gradlew assembleRelease
```

## 安装 APK

### Android 手机安装
1. 将 APK 文件传到手机
2. 在手机上点击 APK 文件
3. 允许安装未知来源应用
4. 完成安装

### 使用方法
1. 打开 "路由器配置扫描器" 应用
2. 点击 "扫描二维码"
3. 授予相机权限
4. 对准路由器配置二维码
5. 获取配置信息并复制

## 技术支持

- 查看构建日志：仓库 → Actions → 选择构建任务
- 查看项目说明：`QRConfigScanner/README.md`
- 二维码生成器：`QRConfigScanner/qr_generator.py`

---

**预期结果**：5-10 分钟后，你就能下载到可安装的 `app-debug.apk` 文件！
